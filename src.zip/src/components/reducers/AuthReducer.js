const initState = {
    un: null,
    role: 0
};

export default function AuthReducer(state = initState, action) {
    switch (action.type) {
        case "login":
            const { un, role } = action.data || {};
            localStorage.setItem("un", un);
            localStorage.setItem("role", role);
            return {
                un: un || null,
                role: role || 0
            };
        case "logout":
            localStorage.removeItem("un");
            localStorage.removeItem("role");
            return {
                un: null,
                role: 0
            };
        default:
            return state;
    }
}
