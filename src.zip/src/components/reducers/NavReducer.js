const initState = "Login"
export default function NavReducer(state=initState, action){
    switch(action.type) {
        case "Login":
            return "Login";
        case "Registration":
            return "Registration";
        case "Profile":
            return "Profile";
        case "Entry":
            return "Entry";
        case "Culture":
            return "Culture";
        case "History":
            return "History";
        case "Home":
            return "Home";
        case "Food":
            return "Food";
        default:
            return "Login";

    }

}