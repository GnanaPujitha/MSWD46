import React, { useState } from 'react';
import History from './History'; // Import the History component
import Food from './Food'; // Import the Food component

function Home() {
  const [showHistory, setShowHistory] = useState(false); // State to control whether to show History component
  const [showWelcomeMessage, setShowWelcomeMessage] = useState(true); // State to control whether to show the welcome message

  // Function to handle click event on the "History" link
  const handleHistoryLinkClick = () => {
    setShowHistory(true);
    setShowWelcomeMessage(false); // Hide the welcome message
  };

  return (
    <div style={{ 
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'flex-start',
      minHeight: '100vh',
      padding: '20px', // Added padding for better spacing
      background: showHistory ? '#fff' : 'linear-gradient(to bottom, #87CEEB, #1E90FF)' // Changed background color to sky blue gradient
    }}>
      {/* Conditionally render the welcome message */}
      {showWelcomeMessage && (
        <h1 style={{ color: '#fff', fontSize: '48px', marginBottom: '20px' }}>Welcome to Indian Culture Website</h1>
      )}

      {/* Conditionally render the history link */}
      {!showHistory && (
        <div style={{ marginBottom: '20px' }}>
          <a href="#" onClick={handleHistoryLinkClick} style={{ fontSize: '24px', color: showHistory ? '#000' : '#fff', textDecoration: 'none', border: showHistory ? '2px solid #000' : '2px solid #fff', padding: '10px 20px', borderRadius: '5px' }}>View History</a>
        </div>
      )}

      {/* Render History component if showHistory is true */}
      {showHistory && <History />}
    </div>
  );
}

export default Home;
