import React, { useState } from 'react';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import axios from 'axios';

export default function Entry() {
    const [formData, setFormData] = useState({
        participantId: '',
        participantName: '',
        eventCategory: 'select',
        traditionalAttire: 'select',
        culturalActivity: 'select',
    });

    function handleChange(event) {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    }

    function handleSubmit() {
        console.log(formData);
        axios.post('http://localhost:8081/entry', formData)
            .then((response) => {
                console.log(response.data);
            })
            .catch((error) => {
                console.error('Error while submitting data:', error);
            });
    }

    function handleUpdate() {
        axios.put('http://localhost:8081/entry', {params: {
            participantId: document.getElementById("idParticipant").value,
            participantName: document.getElementById("idParticipantName").value,
            eventCategory: document.getElementsByName("eventCategory")[0].value,
            traditionalAttire: document.getElementById("idTraditionalAttire").value,
            culturalActivity: document.getElementById("idCulturalActivity").value
        }}).then((response) => {
            console.log(response.data);
        })
    }

    return (
        
        <div>
            Participant ID: <input type="text" name="participantId" value={formData.participantId} onChange={handleChange} /> <br /><br />
            Participant Name: <input type="text" name="participantName" value={formData.participantName} onChange={handleChange} /> <br /><br />
            Event Category:
            <Select
                id="idEventCategory"
                label="Event Category"
                name="eventCategory"
                value={formData.eventCategory}
                onChange={handleChange}
            >
                <MenuItem value="select">Select Event Category</MenuItem>
                <MenuItem value="Festival">Festival</MenuItem>
                <MenuItem value="Traditional Dance">Traditional Dance</MenuItem>
                <MenuItem value="Music Concert">Music Concert</MenuItem>
                <MenuItem value="Art Exhibition">Art Exhibition</MenuItem>
                <MenuItem value="Drama Play">Drama Play</MenuItem>
                <MenuItem value="Food Festival">Food Festival</MenuItem>
                <MenuItem value="Craft Fair">Craft Fair</MenuItem>
                <MenuItem value="Exhibition">Exhibition</MenuItem>
                <MenuItem value="Carnival">Carnival</MenuItem>
                <MenuItem value="Conference">Conference</MenuItem>
                <MenuItem value="Film Festival">Film Festival</MenuItem>
                <MenuItem value="Cultural Fair">Cultural Fair</MenuItem>
                <MenuItem value="Fashion Show">Fashion Show</MenuItem>
                <MenuItem value="Literary Event">Literary Event</MenuItem>
                <MenuItem value="Symposium">Symposium</MenuItem>
                <MenuItem value="Gala Dinner">Gala Dinner</MenuItem>
                <MenuItem value="Quiz Competition">Quiz Competition</MenuItem>
                <MenuItem value="Parade">Parade</MenuItem>
            </Select> <br /><br />
            Traditional Attire:
            <Select
                id="idTraditionalAttire"
                label="Traditional Attire"
                name="traditionalAttire"
                value={formData.traditionalAttire}
                onChange={handleChange}
            >
                <MenuItem value="select">Select Traditional Attire</MenuItem>
                <MenuItem value="Dress Dhoti">Dress Dhoti</MenuItem>
                <MenuItem value="Churidar Suit">Churidar Suit</MenuItem>
                <MenuItem value="Banarasi Sari">Banarasi Sari</MenuItem>
                <MenuItem value="Patiala Suit">Patiala Suit</MenuItem>
                <MenuItem value="Jodhpuri Suit">Jodhpuri Suit</MenuItem>
                <MenuItem value="Angarkha">Angarkha</MenuItem>
                <MenuItem value="Lungi">Lungi</MenuItem>
                <MenuItem value="Kanjeevaram Sari">Kanjeevaram Sari</MenuItem>
                <MenuItem value="Kashmiri Pheran">Kashmiri Pheran</MenuItem>
                <MenuItem value="Mekhela Chador">Mekhela Chador</MenuItem>
                <MenuItem value="Sherwani with Pagdi">Sherwani with Pagdi</MenuItem>
                <MenuItem value="Lehenga">Lehenga</MenuItem>
                <MenuItem value="Anarkali Dress">Anarkali Dress</MenuItem>
                <MenuItem value="Ghagra Choli">Ghagra Choli</MenuItem>
                <MenuItem value="Lengha Saree">Lengha Saree</MenuItem>
                <MenuItem value="Pavadai Dhavani">Pavadai Dhavani</MenuItem>
                <MenuItem value="Sharara Suit">Sharara Suit</MenuItem>
                <MenuItem value="Palazzo Suit">Palazzo Suit</MenuItem>
                <MenuItem value="Frock">Frock</MenuItem>
                <MenuItem value="Chaniya Choli">Chaniya Choli</MenuItem>
                <MenuItem value="Kurti with Skirt">Kurti with Skirt</MenuItem>
                <MenuItem value="Dhoti Style Dress">Dhoti Style Dress</MenuItem>
            </Select> <br /><br />
            Cultural Activity:
            <Select
                id="idCulturalActivity"
                label="Cultural Activity"
                name="culturalActivity"
                value={formData.culturalActivity}
                onChange={handleChange}
            >
                <MenuItem value="select">Select Cultural Activity</MenuItem>
                <MenuItem value="Classical Dance Performance">Classical Dance Performance</MenuItem>
                <MenuItem value="Folk Dance Performance">Folk Dance Performance</MenuItem>
                <MenuItem value="Bollywood Dance Performance">Bollywood Dance Performance</MenuItem>
                <MenuItem value="Street Play">Street Play</MenuItem>
                <MenuItem value="Cultural Quiz">Cultural Quiz</MenuItem>
                <MenuItem value="Art and Craft Exhibition">Art and Craft Exhibition</MenuItem>
                <MenuItem value="Music Concert">Music Concert</MenuItem>
                <MenuItem value="Drama Play">Drama Play</MenuItem>
                <MenuItem value="Poetry Recitation">Poetry Recitation</MenuItem>
                <MenuItem value="Cooking Demonstration">Cooking Demonstration</MenuItem>
                <MenuItem value="Traditional Music Performance">Traditional Music Performance</MenuItem>
                <MenuItem value="Spoken Word Poetry">Spoken Word Poetry</MenuItem>
                <MenuItem value="Rangoli Making">Rangoli Making</MenuItem>
                <MenuItem value="Henna Art Workshop">Henna Art Workshop</MenuItem>
                <MenuItem value="Mehendi Design Competition">Mehendi Design Competition</MenuItem>
                <MenuItem value="Fashion Show">Fashion Show</MenuItem>
                <MenuItem value="Photography Exhibition">Photography Exhibition</MenuItem>
                <MenuItem value="Cultural Debate">Cultural Debate</MenuItem>
                <MenuItem value="Indian Art and Sculpture Exhibition">Indian Art and Sculpture Exhibition</MenuItem>
                <MenuItem value="Traditional Storytelling">Traditional Storytelling</MenuItem>
                <MenuItem value="Dandiya Night">Dandiya Night</MenuItem>
            </Select> <br /><br />
            <button onClick={handleSubmit}> Save Data </button>
            <button onClick={handleUpdate}> Update Data </button>
        </div>
    );
}
