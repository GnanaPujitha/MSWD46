export default function Error() {
    return(
        <div>
            You are not Logged In as a Permitted User
        </div>
    );
}