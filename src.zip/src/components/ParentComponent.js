import React from 'react';
import { connect } from 'react-redux';
import ResponsiveAppBar from './ResponsiveAppBar';
import { logoutUser } from './actions/authActions';

function ParentComponent({ isLoggedIn, logoutUser }) {
  return (
    <div>
      <ResponsiveAppBar isLoggedIn={isLoggedIn} handleLogout={logoutUser} />
      {/* Other components */}
    </div>
  );
}

const mapStateToProps = (state) => ({
  isLoggedIn: state.auth.isLoggedIn,
});

const mapDispatchToProps = {
  logoutUser,
};

export default connect(mapStateToProps, mapDispatchToProps)(ParentComponent);